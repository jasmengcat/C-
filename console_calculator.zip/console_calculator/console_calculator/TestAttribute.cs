﻿using System;

namespace console_calculator
{
    internal class TestAttribute : Attribute
    {
    }
}