﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Double numOne = 0;
            Double numTwo = 0;
            Double answer = 0;
            string operation;
            

            Console.Write("Enter the first number: ");
            numOne = Convert.ToDouble(Console.ReadLine());
            Console.Write("Choose the operation (+, -, *, /): ");
            operation = Console.ReadLine();
            Console.Write("Enter the second number: ");
            numTwo = Convert.ToDouble(Console.ReadLine());

            
            switch (operation)
            {
                case "+":
                    answer = numOne + numTwo;
                    break;
                case "-":
                    answer = numOne - numTwo;
                    break;
                case "*":
                    answer = numOne * numTwo;
                    break;
                case "/":
                    answer = numOne / numTwo;
                    break;
            }

            Console.WriteLine("The answer is {0}", answer);
            Console.ReadLine();
        }
    }
}
